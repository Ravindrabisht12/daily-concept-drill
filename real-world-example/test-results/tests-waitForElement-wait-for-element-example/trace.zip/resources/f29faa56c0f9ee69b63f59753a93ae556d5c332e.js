
    (function() {

      function initChatWidget(){
        // Embed chat button and iframe in the HTML body
        const chatButtonHTML = `
          <button id="brill-chat-widget-button" style="position: fixed; bottom: 20px; right: 20px; background-color: #102547; color: white; border: none; border-radius: 50%; width: 60px; height: 60px; cursor: pointer; box-shadow: 0 0 10px rgba(0,0,0,0.3); z-index: 100001; display: flex; align-items: center; justify-content: center; font-size: 24px;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z"></path>
            </svg>
          </button>
        `;

        const chatIframeHTML = `
          <iframe id="brill-chat-window" src="https://production.dout650pxvd1b.amplifyapp.com/chatbot/widget" style="position: fixed; bottom: 90px; right: 20px; width: 32%; height: 80%; border: 1px solid #eaeded; background: white; box-shadow: rgba(0, 0, 0, 0.2) 0px 4px 8px; border-radius: 8px; display: none; z-index: 100000;"></iframe>
        `;

        // Inject HTML elements into the body
        const bodyElement = document.querySelector('body');

        if(!bodyElement) return;
        bodyElement.insertAdjacentHTML('beforeend', chatButtonHTML);
        bodyElement.insertAdjacentHTML('beforeend', chatIframeHTML);
        
        // Prevent multiple initializations
        if (document.getElementById('brill-chat-widget-container')) {
          return;
        }

        const chatButton = document.getElementById('brill-chat-widget-button');
        const chatIframe = document.getElementById('brill-chat-window');

        // If chat button or iframe is not found, return
        if(!chatButton || !chatIframe) return;
        
        let isOpen = false;

        // Toggle iframe visibility on button click
        chatButton.onclick = function () {
          isOpen = !isOpen;
          chatIframe.style.display = isOpen ? 'block' : 'none';

          window.dataLayer = window.dataLayer || [];
          if(isOpen){
            window.dataLayer.push({
              event: "open_chat_window"
            });
          }else{
            window.dataLayer.push({
              event: "close_chat_window"
            }); 
          }
        };

        // Handle window resize to adjust iframe position and size
        function handleResize() {
          const isMobile = window.innerWidth < 768;
          chatIframe.style.width = isMobile ? '90%' : '32%';
          chatIframe.style.right = isMobile ? '5%' : '20px';
        }

        window.addEventListener('resize', handleResize);
        handleResize(); // Call on initial load

        // Handle close message from iframe
        function handleMessage(event) {
          if (event.data === 'closeChatbot') {
            isOpen = false;
            chatIframe.style.display = 'none';

            window.dataLayer = window.dataLayer || [];
            window.dataLayer.push({
              event: "close_chat_window"
            });
          }
        }

        window.addEventListener('message', handleMessage);

        // Cleanup event listeners on page unload
        window.addEventListener('unload', function () {
          window.removeEventListener('resize', handleResize);
          window.removeEventListener('message', handleMessage);
        });
      }
      
      // Expose initialization function globally
      window.initChatWidget = initChatWidget;
    })();
  